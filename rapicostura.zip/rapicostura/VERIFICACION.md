# Verificación del prototipo

17/10/2026 · Validación en navegador Chromium del entorno de trabajo.

## Resultado

**29 comprobaciones funcionales correctas** en `tests/flujo.html`. Las pruebas cargan el HTML y JavaScript reales en un iframe móvil de 390 px; usan claves de localStorage y base IndexedDB exclusivas de prueba y las eliminan al terminar. No reemplazan datos de la demostración.

Se verificaron las validaciones del formulario, selección accesible, exclusión de origen, fecha/hora autocompletadas y persistencia de los valores editados, registro con imagen y lectura posterior, acceso de recepción exclusivo del destino, finalización persistida, animaciones para costureras, sección única Admin y combinación de filtros de estado y sede (origen o destino).

El recorrido de video usa un video WebM real generado a partir de un canvas, sin acceder a la cámara: se registra desde Yanahuara hacia Cayma, se cambia al perfil Cayma, se comprueba el estado En camino y la exclusión de recepciones ajenas, se carga el video desde IndexedDB, se verifica la decodificación (ancho 100 px) y se inicia su reproducción con `play()`. Luego se confirma la recepción y se verifica el check animado. Se comprueba también que otro perfil no pueda abrir el envío y que la dueña no pueda recibirlo.

La página muestra los 29 resultados individuales. La comprobación final confirma ausencia de desbordamiento horizontal a 390 px.

Además: `node --check rapicostura/app.js` correcto. Inspección visual de pantalla principal en escritorio, formularios emergentes y vista móvil. Recorrido manual de recepción de ejemplo hasta el mensaje de proceso finalizado.

## Ejecutar nuevamente

Inicia el servidor del README y visita `http://127.0.0.1:4173/tests/flujo.html`. La página muestra cada resultado y una vista móvil del prototipo de prueba. El video de prueba es un clip WebM válido generado por el navegador y se valida su carga, decodificación y reproducción. No contiene capturas de personas ni usa la cámara.

## Pendiente de comprobar en dispositivo físico

No se verificaron captura fotográfica real, grabación con cámara física ni selector de galería en Android. Son implementaciones con APIs nativas de navegador sujetas a HTTPS/localhost, permisos, formatos y compatibilidad del dispositivo. Tampoco se simularon cuotas agotadas, navegación privada, interrupción durante escritura o accesibilidad con lector de pantalla real. Las rutas de error están implementadas, pero estas condiciones requieren pruebas adicionales antes de producción.

La persistencia comprobada se ejecutó por servidor local; abrir con file:// puede variar entre navegadores. No se probaron autenticación ni servicios externos porque no forman parte del alcance.
